# Str1k3-Tor-Router
UPDATED FOR NEWER SYSTEMS


A script to automate the creation of a "TOR" router on Debian based systems including Raspberry Pi and install the required tools to do so.

Installation is easy !

git clone https://github.com/UbuntuStrike/Str1k3-Tor-Router.git

cd Str1k3-Tor-Router

**** NEED TO BE ROOT!!!!!

sudo su 

chmod +x Str1k3.sh

./Str1k3.sh

and follow instructions from there!

To STOP and revert settings open another root terminal type "ctrl+c" 

then

./Str1k3.sh and ENTER "RESTORE" when prompted

********************************************************************************************************************************
KNOWN ISSUES :                                                                                                                 
Depending on your wifi adapter you may need to find and install a different version of hostapd
If you google enough you'll find it but it's a pain in the ass so..... yeah have fun with that, I did LOL
these isuues exist with older Brodcom and realtek nic's sorry not my fault

